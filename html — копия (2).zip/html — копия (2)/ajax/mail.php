<?php
echo "привет";

?>
