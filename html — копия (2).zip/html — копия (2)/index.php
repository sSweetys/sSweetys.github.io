

 <form action="send.php" method="post" >
              <fieldset>
                <div class="row">
                  <section class="col col-6">
                    <label class="label">Имя</label>
                    <label class="input"> <i class="icon-append fa fa-user"></i>
                      <input name="name" id="name" type="text">
                    </label>
                  </section>
                  <section class="col col-6">
                    <label class="label">E-mail</label>
                    <label class="input"> <i class="icon-append fa fa-envelope-o"></i>
                      <input name="email" id="email" type="email">
                    </label>
                  </section>
                </div>
                <section>
                  <label class="label">Тема</label>
                  <label class="input"> <i class="icon-append fa fa-tag"></i>
                    <input name="subject" id="subject" type="text">
                  </label>
                </section>
                <section>
                  <label class="label">Сообщение</label>
                  <label class="textarea"> <i class="icon-append fa fa-comment"></i>
                    <textarea rows="4" name="message" id="message"></textarea>
                  </label>
                </section>
                <section>
                  <label class="checkbox">
                    <input name="copy" type="checkbox">
                    <i></i><small class="pull-left font-white">Отправить копию письма на мой E-mail</small></label>
                </section>
              </fieldset>
              <footer>
                <button type="submit" class="button button-secondary">Отправить Сообщение</button>
              </footer>
              <div class="message"> <i class="fa fa-check"></i>
                <p>Ваше сообщение успешно отправлено!</p>
              </div>
            </form>  
</body>