$("#sendMail").on("click", function()   {

  var email = $("#email").val().trim();
  var name = $("#name").val().trim();
  var subject = $("#subject").val().trim();
  var message = $("#message").val().trim();


})

$.ajax({
  url: 'telegram.php',
  type: 'post',
  cache: false,
  data: {'name': name, 'email': email, 'subject': subject, 'message': message},
  dataType: 'html',
  beforeSend: function(){
    $("#sendMail").prop("disabled", true);
  },

  success: function(data) {
  if(!data)
    alert("были ошибки, сообщение не отправлено!");
  else
    $("#sky-form").trigger("reset");

  $("#sendMail").prop("disabled", false);
    }



});
