<?php 


$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];



$name = htmlspecialchars($name);
$email = htmlspecialchars($email);
$subject = htmlspecialchars($subject);
$message = htmlspecialchars($message);


$name = urldecode($name);
$email = urldecode($email);
$subject = urldecode($subject);
$message = urldecode($message);



$name = trim($name);
$email = trim($email);
$subject = trim($subject);
$message = trim($message);


if (mail("doman96x@gmail.com",
		"Новое письмо с сайта",
		"Логин:  ".$name."\n".
		"Email:  ".$email."\n".
		"Тема:   ".$subject."\n".
		"Сообщение:".$message,
		"From: no-reply@mydomain.ru \r\n")

) { 
	echo ('Письмо успешно отправлено!');
}

else {
	echo ('Есть ошибки! Проверьте данные...');
}







 ?>