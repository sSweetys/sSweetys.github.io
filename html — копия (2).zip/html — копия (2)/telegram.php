<?php

/* https://api.telegram.org/bot1829374017:AAEWnT1eZIg7CGUFReJpc4znGKLWg2VVchM/getUpdates,
где, XXXXXXXXXXXXXXXXXXXXXXX - токен вашего бота, полученный ранее */

$name = $_POST['name'];
$subject = $_POST['subject'];
$email = $_POST['email'];
$message = $_POST['message'];
$token = "1829374017:AAEWnT1eZIg7CGUFReJpc4znGKLWg2VVchM";
$chat_id = "-573435482";
$arr = array(
  'Имя пользователя: ' => $name,
  'Тема: ' => $subject,
  'Email' => $email,
  'Сообщение' => $message,
);

foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

if ($sendToTelegram) {
  header('Location: thank-you.html');
} else {
  echo "Error";
}
?>
